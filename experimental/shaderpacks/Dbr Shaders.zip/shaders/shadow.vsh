#version 120
// Dbr Shaders: shadow map. Distorted (more texels near the player); plants move as in gbuffers_terrain.
#include "/lib/settings.glsl"
#include "/lib/shadow.glsl"

attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;

varying vec2 uv;
varying vec4 col;

vec3 wave(vec3 world, float amount) {
    float t = frameTimeCounter * (1.6 + rainStrength);
    float s = 1.0 + rainStrength * 1.5;
    vec3 w;
    w.x = sin(t * 1.3 + world.x * 0.7 + world.z * 0.3) * 0.045 + sin(t * 2.7 + world.z * 1.1) * 0.02;
    w.z = sin(t * 1.1 + world.z * 0.6 + world.x * 0.4) * 0.045 + sin(t * 2.3 + world.x * 0.9) * 0.02;
    w.y = 0.0;
    return w * amount * s;
}

void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    col = gl_Color;
    vec4 player = shadowModelViewInverse * (gl_ModelViewMatrix * gl_Vertex);
#ifdef WAVING_PLANTS
    bool top = uv.y < mc_midTexCoord.y;
    float wind = smoothstep(0.4, 0.9, (gl_TextureMatrix[1] * gl_MultiTexCoord1).y);
    if (mc_Entity.x == ID_PLANT && top) player.xyz += wave(player.xyz + cameraPosition, wind);
    if (mc_Entity.x == ID_DOUBLE_PLANT) player.xyz += wave(player.xyz + cameraPosition, wind * (top ? 1.0 : 0.4));
    if (mc_Entity.x == ID_LEAVES) player.xyz += wave(player.xyz + cameraPosition, wind * 0.35);
#endif
    vec4 p = shadowProjection * (shadowModelView * player);
    p.xy = distort(p.xy);
    gl_Position = p;
}
