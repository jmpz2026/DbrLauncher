#version 120
// Dbr Shaders: held item and arm (shadowPos is outside the map, so only the light map applies).
#include "/lib/settings.glsl"
#include "/lib/shadow.glsl"
#include "/lib/light.glsl"

uniform sampler2D texture;
uniform vec4 entityColor;

varying vec2 uv;
varying vec2 lm;
varying vec4 col;
varying vec3 shadowPos;
varying float NdotL;

void main() {
    vec4 c = texture2D(texture, uv) * col;
    c.rgb = mix(c.rgb, entityColor.rgb, entityColor.a);
    c.rgb *= lit(lm, shadowPos, NdotL);
    c.rgb = mix(c.rgb, gl_Fog.color.rgb, clamp((gl_FogFragCoord - gl_Fog.start) * gl_Fog.scale, 0.0, 1.0));
/* DRAWBUFFERS:01 */
    gl_FragData[0] = c;
    gl_FragData[1] = vec4(0.0, 0.0, 0.0, c.a);
}
