#version 120
// Dbr Shaders: terrain. colortex0 color, colortex1 flags (r emissive, g water).
#include "/lib/settings.glsl"
#include "/lib/shadow.glsl"
#include "/lib/light.glsl"

uniform sampler2D texture;

varying vec2 uv;
varying vec2 lm;
varying vec4 col;
varying vec3 shadowPos;
varying float NdotL;
varying float material;

void main() {
    vec4 c = texture2D(texture, uv) * col;
    float emissive = 0.0;
    if (abs(material - ID_EMISSIVE) < 0.5) {
        emissive = 1.0;
        c.rgb *= texture2D(lightmap, vec2(lm.x, 0.0)).rgb * 0.3 + 0.9;
    } else {
        c.rgb *= lit(lm, shadowPos, NdotL);
    }
    c.rgb = mix(c.rgb, gl_Fog.color.rgb, clamp((gl_FogFragCoord - gl_Fog.start) * gl_Fog.scale, 0.0, 1.0));
/* DRAWBUFFERS:01 */
    gl_FragData[0] = c;
    gl_FragData[1] = vec4(emissive, 0.0, 0.0, 1.0);
}
