#version 120
// Dbr Shaders: terrain. colortex0 color, colortex1 flags (r emissive, g water).
#include "/lib/settings.glsl"
#include "/lib/shadow.glsl"
#include "/lib/light.glsl"

uniform sampler2D texture;

varying vec2 uv;
varying vec2 lm;
varying vec4 col;
varying vec3 shadowPos;
varying float NdotL;
varying float material;
varying vec3 viewPos;

void main() {
    vec4 c = texture2D(texture, uv) * col;
    // Light facing from the face itself (screen derivatives): it does not depend on the normal attribute.
    float ndl = NdotL;
    bool plant = abs(material - ID_PLANT) < 0.5 || abs(material - ID_DOUBLE_PLANT) < 0.5 || abs(material - ID_LEAVES) < 0.5;
    if (!plant) {
        ndl = dot(faceNormal(viewPos), normalize(shadowLightPosition));
    }
    float emissive = 0.0;
    if (abs(material - ID_EMISSIVE) < 0.5) {
        emissive = 1.0;
        c.rgb *= texture2D(lightmap, vec2(lm.x, 0.0)).rgb * 0.3 + 0.9;
    } else {
        c.rgb *= lit(lm, shadowPos, ndl);
    }
    c.rgb = mix(c.rgb, gl_Fog.color.rgb, clamp((gl_FogFragCoord - gl_Fog.start) * gl_Fog.scale, 0.0, 1.0));
/* DRAWBUFFERS:01 */
    gl_FragData[0] = c;
    gl_FragData[1] = vec4(emissive, 0.0, 0.0, 1.0);
}
