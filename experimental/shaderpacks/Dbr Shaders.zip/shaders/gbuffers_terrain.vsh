#version 120
// Dbr Shaders: terrain. Waving plants, light facing, shadow position.
#include "/lib/settings.glsl"
#include "/lib/vertex.glsl"

attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;

varying float material;

vec3 wave(vec3 world, float amount) {
    float t = frameTimeCounter * (1.6 + rainStrength);
    float s = 1.0 + rainStrength * 1.5;
    vec3 w;
    w.x = sin(t * 1.3 + world.x * 0.7 + world.z * 0.3) * 0.045 + sin(t * 2.7 + world.z * 1.1) * 0.02;
    w.z = sin(t * 1.1 + world.z * 0.6 + world.x * 0.4) * 0.045 + sin(t * 2.3 + world.x * 0.9) * 0.02;
    w.y = 0.0;
    return w * amount * s;
}

void main() {
    vec4 player = gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex);
    material = mc_Entity.x;
    float facing = -1.0;
#ifdef WAVING_PLANTS
    vec2 tex = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    bool top = tex.y < mc_midTexCoord.y;
    float lmSky = (gl_TextureMatrix[1] * gl_MultiTexCoord1).y;
    float wind = smoothstep(0.4, 0.9, lmSky);
    if (mc_Entity.x == ID_PLANT && top) player.xyz += wave(player.xyz + cameraPosition, wind);
    if (mc_Entity.x == ID_DOUBLE_PLANT) player.xyz += wave(player.xyz + cameraPosition, wind * (top ? 1.0 : 0.4));
    if (mc_Entity.x == ID_LEAVES) player.xyz += wave(player.xyz + cameraPosition, wind * 0.35);
#endif
    // Plants and leaves have no real facing: light them as half-facing so both sides look the same.
    if (mc_Entity.x == ID_PLANT || mc_Entity.x == ID_DOUBLE_PLANT || mc_Entity.x == ID_LEAVES) facing = 0.6;
    setupVertex(player, normalize(gl_NormalMatrix * gl_Normal), facing);
}
