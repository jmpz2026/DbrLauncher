#version 120
// Dbr Shaders: on the finished scene, ambient occlusion in corners, sky reflection on water, warm distance haze and
// sun rays.
#include "/lib/settings.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 upPosition;
uniform vec3 sunPosition;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform float rainStrength;
uniform float far;
uniform float near;
uniform float viewWidth;
uniform float viewHeight;
uniform float aspectRatio;
uniform int isEyeInWater;

varying vec2 uv;

vec3 viewAt(vec2 p, float d) {
    vec4 v = gbufferProjectionInverse * vec4(vec3(p, d) * 2.0 - 1.0, 1.0);
    return v.xyz / v.w;
}

float sunHeight() {
    return dot(normalize(sunPosition), normalize(upPosition));
}

// Warm tint of the air: the sun colour near the horizon, plain fog colour high up.
vec3 hazeColor(vec3 dir) {
    float h = max(sunHeight(), 0.0);
    float day = smoothstep(-0.08, 0.06, sunHeight());
    vec3 warm = mix(vec3(1.0, 0.70, 0.45), vec3(1.0, 0.92, 0.80), smoothstep(0.05, 0.6, h));
    float towardSun = pow(max(dot(dir, normalize(sunPosition)), 0.0), 4.0);
    // Pale blue air by day (the vanilla fog colour is grey at golden hour), warm only toward the sun.
    vec3 air = mix(vec3(0.78, 0.84, 0.92), warm * 0.95, 0.15 + 0.6 * towardSun);
    vec3 c = mix(fogColor, air, day);
    return mix(c, fogColor, rainStrength);
}

// Sky of the look, painted here over whatever vanilla left (its dome, sunset fan and fog come out flat grey at
// golden hour): pale celeste overhead, lighter at the horizon, peach toward a low sun and lavender away from it.
// The sun disk and the stars stay (anything much brighter than the gradient).
vec3 paintSky(vec3 c, vec3 dir) {
    vec3 up = normalize(upPosition);
    vec3 sun = normalize(sunPosition);
    float h = sunHeight();
    float day = smoothstep(-0.08, 0.06, h);
    float above = max(dot(dir, up), 0.0);
    float horizon = 1.0 - smoothstep(0.0, 0.45, above);
    // Pale, soft zenith: a quarter of the way toward peach grey, so it never reads as solid blue.
    vec3 sky = mix(mix(vec3(0.50, 0.66, 0.98), vec3(0.85, 0.78, 0.72), 0.28), vec3(0.84, 0.86, 0.92), horizon);
    float golden = day * (1.0 - smoothstep(0.08, 0.5, h));
    float toward = pow(max(dot(dir, sun), 0.0), 2.0);
    float away = pow(max(-dot(dir, sun), 0.0), 1.5);
    sky = mix(sky, vec3(1.0, 0.76, 0.58), golden * horizon * (0.35 + 0.55 * toward));
    sky = mix(sky, vec3(0.82, 0.74, 0.90), golden * horizon * away * 0.5);
    sky = mix(sky, fogColor, rainStrength * 0.8);
    float keep = smoothstep(0.08, 0.3, dot(c, vec3(0.333)) - dot(sky, vec3(0.333)));
    return mix(c, mix(sky, c, keep), day);
}

#ifdef SSAO
// Eight samples on a spiral in screen space, compared in view depth. Cheap, and enough for block corners.
float ambientOcclusion(vec3 pos, float d) {
    float radius = 0.55;
    vec4 clip = gbufferProjection * vec4(pos + vec3(radius, radius, 0.0), 1.0);
    vec2 r = abs(clip.xy / clip.w * 0.5 + 0.5 - uv);
    // Interleaved gradient noise: an even, stable pattern. The old fract(sin()) hash lost precision on large
    // pixel coordinates and left grain and horizontal streaks.
    float noise = fract(52.9829189 * fract(dot(floor(uv * vec2(viewWidth, viewHeight)), vec2(0.06711056, 0.00583715))));
    float occ = 0.0;
    for (int i = 0; i < 8; i++) {
        float a = (float(i) + noise) * 2.39996;
        float k = (float(i) + 0.5) / 8.0;
        vec2 o = vec2(cos(a), sin(a)) * r * k;
        float sd = texture2D(depthtex0, uv + o).r;
        vec3 sp = viewAt(uv + o, sd);
        float diff = sp.z - pos.z;
        // In front of us within the radius occludes; far in front (a pillar in the foreground) does not.
        occ += step(0.06, diff) * (1.0 - smoothstep(radius * 0.6, radius * 2.0, diff));
    }
    return 1.0 - occ / 8.0 * SSAO_STRENGTH;
}
#endif

#ifdef GODRAYS
// Radial blur of the sky mask toward the sun's screen position. Only strong when the sun is low and in view.
vec3 sunRays() {
    vec3 sunView = sunPosition;
    if (sunView.z > 0.0) return vec3(0.0);
    vec4 sc = gbufferProjection * vec4(sunView, 1.0);
    vec2 sp = sc.xy / sc.w * 0.5 + 0.5;
    float h = sunHeight();
    float low = smoothstep(-0.05, 0.08, h) * (1.0 - smoothstep(0.25, 0.65, h));
    vec2 toSun = sp - uv;
    float fade = 1.0 - smoothstep(0.3, 1.1, length(toSun * vec2(aspectRatio, 1.0)));
    if (low * fade <= 0.0) return vec3(0.0);
    vec2 stepv = toSun / 20.0;
    float noise = fract(sin(dot(uv * vec2(viewWidth, viewHeight), vec2(41.3, 289.1))) * 13758.5);
    vec2 p = uv + stepv * noise;
    float sum = 0.0;
    for (int i = 0; i < 20; i++) {
        sum += step(1.0, texture2D(depthtex0, clamp(p, 0.001, 0.999)).r);
        p += stepv;
    }
    float rays = sum / 20.0 * low * fade * (1.0 - rainStrength);
    return vec3(1.0, 0.72, 0.42) * rays * GODRAYS_STRENGTH;
}
#endif

void main() {
    vec3 c = texture2D(colortex0, uv).rgb;
    vec4 flags = texture2D(colortex1, uv);
    float d = texture2D(depthtex0, uv).r;
    if (d < 1.0) {
        vec3 view = viewAt(uv, d);
        vec3 dir = normalize(view);
        float dist = length(view);
#ifdef SSAO
        if (flags.r < 0.5 && flags.b < 0.5 && d > 0.56) c *= ambientOcclusion(view, d);
#endif
        if (isEyeInWater == 0) {
#if WATER_REFLECTION == 1
            if (flags.g > 0.5) {
                float up = max(dot(-dir, normalize(upPosition)), 0.0);
                float fresnel = 0.04 + 0.96 * pow(1.0 - up, 5.0);
                c = mix(c, skyColor * 1.1 + fogColor * 0.2, clamp(fresnel, 0.0, 0.75));
                // Sun glint on the water surface.
                vec3 refl = reflect(dir, normalize(upPosition));
                float glint = pow(max(dot(refl, normalize(sunPosition)), 0.0), 220.0);
                c += vec3(1.0, 0.85, 0.65) * glint * 1.5 * (1.0 - rainStrength);
            }
#endif
#ifdef HEIGHT_FOG
            vec3 world = (gbufferModelViewInverse * vec4(view, 1.0)).xyz + cameraPosition;
            float low = exp(-max(world.y - 62.0, 0.0) / 28.0);
            float density = FOG_DENSITY * (0.0075 + 0.004 * rainStrength) * (0.5 + 0.5 * low);
            float f = 1.0 - exp(-dist * density);
            f *= smoothstep(0.0, far * 0.12, dist);
            c = mix(c, hazeColor(dir), clamp(f, 0.0, 0.45));
#endif
        }
    }
    // What a mod marked emissive in the sky (the Nucleo star of DbrGalaxiaMod, its planets) keeps its colour:
    // an orange sun is darker than the day gradient and would be painted over.
    if (d >= 1.0 && isEyeInWater == 0) c = mix(paintSky(c, normalize(viewAt(uv, d))), c, step(0.5, flags.r));
#ifdef GODRAYS
    if (isEyeInWater == 0) c += sunRays();
#endif
/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(c, 1.0);
}
