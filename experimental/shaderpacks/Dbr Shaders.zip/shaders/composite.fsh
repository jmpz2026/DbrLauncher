#version 120
// Dbr Shaders: sky reflection on water and height fog, on the finished scene.
#include "/lib/settings.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 upPosition;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform float rainStrength;
uniform float far;
uniform int isEyeInWater;

varying vec2 uv;

void main() {
    vec3 c = texture2D(colortex0, uv).rgb;
    vec4 flags = texture2D(colortex1, uv);
    float d = texture2D(depthtex0, uv).r;
    if (d < 1.0 && isEyeInWater == 0) {
        vec4 view = gbufferProjectionInverse * vec4(vec3(uv, d) * 2.0 - 1.0, 1.0);
        view /= view.w;
        vec3 dir = normalize(view.xyz);
        float dist = length(view.xyz);
#if WATER_REFLECTION == 1
        if (flags.g > 0.5) {
            float up = max(dot(-dir, normalize(upPosition)), 0.0);
            float fresnel = 0.04 + 0.96 * pow(1.0 - up, 5.0);
            c = mix(c, skyColor * 1.1 + fogColor * 0.2, clamp(fresnel, 0.0, 0.75));
        }
#endif
#ifdef HEIGHT_FOG
        vec3 world = (gbufferModelViewInverse * view).xyz + cameraPosition;
        float low = exp(-max(world.y - 62.0, 0.0) / 28.0);
        float density = FOG_DENSITY * (0.0025 + 0.004 * rainStrength) * (0.35 + 0.65 * low);
        float f = 1.0 - exp(-dist * density);
        f *= smoothstep(0.0, far * 0.25, dist);
        c = mix(c, fogColor, clamp(f, 0.0, 0.55));
#endif
    }
/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(c, 1.0);
}
