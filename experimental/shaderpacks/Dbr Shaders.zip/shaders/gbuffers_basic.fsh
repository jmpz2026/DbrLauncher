#version 120
// Dbr Shaders: untextured geometry.
varying vec4 col;

void main() {
/* DRAWBUFFERS:0 */
    gl_FragData[0] = col;
}
