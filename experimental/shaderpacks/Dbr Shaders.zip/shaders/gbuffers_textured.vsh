#version 120
// Dbr Shaders: unlit textured geometry (sky textures, some particles). Vanilla look.
varying vec2 uv;
varying vec4 col;

void main() {
    gl_Position = ftransform();
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    col = gl_Color;
    gl_FogFragCoord = length((gl_ModelViewMatrix * gl_Vertex).xyz);
}
