#version 120
// Dbr Shaders: untextured geometry (block outline, leash, sky shapes). Vanilla look.
varying vec4 col;

void main() {
    gl_Position = ftransform();
    col = gl_Color;
}
