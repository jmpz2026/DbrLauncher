#version 120
// Dbr Shaders: translucent terrain. Water is marked in colortex1.g for the sky reflection in composite.
#include "/lib/settings.glsl"
#include "/lib/shadow.glsl"
#include "/lib/light.glsl"

uniform sampler2D texture;

varying vec2 uv;
varying vec2 lm;
varying vec4 col;
varying vec3 shadowPos;
varying float NdotL;
varying float material;
varying vec3 viewPos;

void main() {
    vec4 c = texture2D(texture, uv) * col;
    float water = abs(material - ID_WATER) < 0.5 ? 1.0 : 0.0;
    c.rgb *= lit(lm, shadowPos, dot(faceNormal(viewPos), normalize(shadowLightPosition)));
    // Water of the look: muted blue-violet.
    if (water > 0.5) c.rgb = mix(c.rgb, vec3(0.34, 0.37, 0.62) * (0.55 + 0.45 * dot(c.rgb, vec3(0.333))), 0.5);
    c.rgb = mix(c.rgb, gl_Fog.color.rgb, clamp((gl_FogFragCoord - gl_Fog.start) * gl_Fog.scale, 0.0, 1.0));
/* DRAWBUFFERS:01 */
    gl_FragData[0] = c;
    gl_FragData[1] = vec4(0.0, water, 0.0, c.a);
}
