#version 120
// Dbr Shaders: translucent terrain. Water is marked in colortex1.g for the sky reflection in composite.
#include "/lib/settings.glsl"
#include "/lib/shadow.glsl"
#include "/lib/light.glsl"

uniform sampler2D texture;

varying vec2 uv;
varying vec2 lm;
varying vec4 col;
varying vec3 shadowPos;
varying float NdotL;
varying float material;

void main() {
    vec4 c = texture2D(texture, uv) * col;
    c.rgb *= lit(lm, shadowPos, NdotL);
    float water = abs(material - ID_WATER) < 0.5 ? 1.0 : 0.0;
    c.rgb = mix(c.rgb, gl_Fog.color.rgb, clamp((gl_FogFragCoord - gl_Fog.start) * gl_Fog.scale, 0.0, 1.0));
/* DRAWBUFFERS:01 */
    gl_FragData[0] = c;
    gl_FragData[1] = vec4(0.0, water, 0.0, c.a);
}
