#version 120
// Dbr Shaders: shadow map. Cut-out leaves and plants cast their real shape.
uniform sampler2D tex;
varying vec2 uv;
varying vec4 col;

void main() {
    vec4 c = texture2D(tex, uv) * col;
    if (c.a < 0.1) discard;
    gl_FragData[0] = c;
}
