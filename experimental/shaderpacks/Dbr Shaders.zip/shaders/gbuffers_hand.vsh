#version 120
// Dbr Shaders: held item and arm. Its matrices are not the world's, so no shadow lookup: light map only.
#include "/lib/settings.glsl"
#include "/lib/vertex.glsl"

void main() {
    vec4 player = gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex);
    setupVertex(player, normalize(gl_NormalMatrix * gl_Normal), 1.0);
    gl_Position = ftransform();
    shadowPos = vec3(2.0);
}
