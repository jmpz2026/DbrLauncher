#version 120
// Dbr Shaders: unlit textured geometry.
uniform sampler2D texture;
varying vec2 uv;
varying vec4 col;

void main() {
    vec4 c = texture2D(texture, uv) * col;
/* DRAWBUFFERS:0 */
    gl_FragData[0] = c;
}
