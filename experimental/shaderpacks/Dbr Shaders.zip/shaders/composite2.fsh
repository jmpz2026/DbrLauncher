#version 120
// Dbr Shaders: bloom, part 2. colortex3 blurred up and down into colortex4.
uniform sampler2D colortex3;
uniform float viewHeight;

varying vec2 uv;

void main() {
    float py = 2.0 / viewHeight;
    vec3 s = texture2D(colortex3, uv).rgb * 0.2270;
    s += (texture2D(colortex3, uv + vec2(0.0, py)).rgb + texture2D(colortex3, uv - vec2(0.0, py)).rgb) * 0.1945;
    s += (texture2D(colortex3, uv + vec2(0.0, 2.0 * py)).rgb + texture2D(colortex3, uv - vec2(0.0, 2.0 * py)).rgb)
        * 0.1216;
    s += (texture2D(colortex3, uv + vec2(0.0, 3.0 * py)).rgb + texture2D(colortex3, uv - vec2(0.0, 3.0 * py)).rgb)
        * 0.0540;
    s += (texture2D(colortex3, uv + vec2(0.0, 4.0 * py)).rgb + texture2D(colortex3, uv - vec2(0.0, 4.0 * py)).rgb)
        * 0.0162;
/* DRAWBUFFERS:4 */
    gl_FragData[0] = vec4(s, 1.0);
}
