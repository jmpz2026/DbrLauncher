// Dbr Shaders: vertex part shared by the lit gbuffers. Needs settings.glsl before it.

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightPosition;

varying vec2 uv;
varying vec2 lm;
varying vec4 col;
varying vec3 shadowPos;
varying float NdotL;

// Light map coordinates, vertex color, light facing and the shadow position of a vertex given in player space
// (camera-relative world space).
void setupVertex(vec4 player, vec3 normal, float facing) {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lm = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    col = gl_Color;
    NdotL = facing >= 0.0 ? facing : dot(normal, normalize(shadowLightPosition));
#ifdef SHADOWS
    shadowPos = (shadowProjection * (shadowModelView * player)).xyz;
#else
    shadowPos = vec3(2.0);
#endif
    vec4 view = gbufferModelView * player;
    gl_Position = gl_ProjectionMatrix * view;
    gl_FogFragCoord = length(view.xyz);
}
