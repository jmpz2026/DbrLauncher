// Dbr Shaders: shadow map distortion and lookup. More resolution near the player, less far away.

const float DISTORT = 0.85;

vec2 distort(vec2 p) {
    float f = length(p) * DISTORT + (1.0 - DISTORT);
    return p / f;
}

float distortFactor(vec2 p) {
    return length(p) * DISTORT + (1.0 - DISTORT);
}

// Depth test blended between the four nearest texels: the lit/shadow edge moves smoothly inside a texel instead
// of jumping a whole texel, which is what draws stair steps along shadow edges.
float shadowBilinear(sampler2D map, vec2 uv, float z, float texel) {
    vec2 st = uv / texel - 0.5;
    vec2 i = floor(st);
    vec2 f = st - i;
    vec2 b = (i + 0.5) * texel;
    float a = step(z, texture2D(map, b).r);
    float c = step(z, texture2D(map, b + vec2(texel, 0.0)).r);
    float d = step(z, texture2D(map, b + vec2(0.0, texel)).r);
    float e = step(z, texture2D(map, b + vec2(texel, texel)).r);
    return mix(mix(a, c, f.x), mix(d, e, f.x), f.y);
}

// pos: clip-space position in the shadow projection (before distortion). 1 = lit, 0 = in shadow.
float shadowAt(sampler2D map, vec3 pos, float NdotL) {
    float f = distortFactor(pos.xy);
    vec3 p = vec3(pos.xy / f, pos.z) * 0.5 + 0.5;
    if (p.x <= 0.0 || p.y <= 0.0 || p.x >= 1.0 || p.y >= 1.0 || p.z >= 1.0) return 1.0;
    // Slope-scaled bias in blocks, then to depth units. A texel covers 2*shadowDistance/res*f blocks (f grows away
    // from the player); with grazing light one texel spans tan(angle) texels of depth. Depth 0..1 = 256 blocks
    // (orthographic box, near 0.05, far 256). Too little bias gives acne: stripes and swirls on flat ground at sunset.
    float texel = 1.0 / float(shadowMapResolution);
    float texelBlocks = 2.0 * shadowDistance * texel * f;
    float n = clamp(NdotL, 0.05, 1.0);
    float slope = min(sqrt(1.0 - n * n) / n, 8.0);
    float filterR = SHADOW_FILTER == 3 ? 2.5 : (SHADOW_FILTER == 2 ? 2.0 : (SHADOW_FILTER == 1 ? 1.0 : 0.5));
    float bias = texelBlocks * (0.6 + filterR * 0.5) * (1.0 + slope) / 256.0;
    float z = p.z - bias;
#if SHADOW_FILTER == 0
    return step(z, texture2D(map, p.xy).r);
#elif SHADOW_FILTER == 1
    float s = 0.0;
    s += step(z, texture2D(map, p.xy + vec2(-0.5, -0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(0.5, -0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(-0.5, 0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(0.5, 0.5) * texel).r);
    return s * 0.25;
#elif SHADOW_FILTER == 3
    // 4x4 grid of bilinear tests: a smooth tent about 4 texels wide, without the per-pixel noise of a rotated
    // disc (that noise crawls between video frames). 64 fetches: only the GRABAR profile uses it.
    float s = 0.0;
    for (int y = 0; y < 4; y++) {
        for (int x = 0; x < 4; x++) {
            s += shadowBilinear(map, p.xy + (vec2(float(x), float(y)) - 1.5) * texel, z, texel);
        }
    }
    return s / 16.0;
#else
    float s = 0.0;
    s += step(z, texture2D(map, p.xy + vec2(-1.5, -0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(-1.5, 0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(-0.5, -1.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(-0.5, -0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(-0.5, 0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(-0.5, 1.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(0.5, -1.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(0.5, -0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(0.5, 0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(0.5, 1.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(1.5, -0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(1.5, 0.5) * texel).r);
    return s / 12.0;
#endif
}
