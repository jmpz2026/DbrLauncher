// Dbr Shaders: shadow map distortion and lookup. More resolution near the player, less far away.

const float DISTORT = 0.85;

vec2 distort(vec2 p) {
    float f = length(p) * DISTORT + (1.0 - DISTORT);
    return p / f;
}

float distortFactor(vec2 p) {
    return length(p) * DISTORT + (1.0 - DISTORT);
}

// pos: clip-space position in the shadow projection (before distortion). 1 = lit, 0 = in shadow.
float shadowAt(sampler2D map, vec3 pos, float NdotL) {
    float f = distortFactor(pos.xy);
    vec3 p = vec3(pos.xy / f, pos.z) * 0.5 + 0.5;
    if (p.x <= 0.0 || p.y <= 0.0 || p.x >= 1.0 || p.y >= 1.0 || p.z >= 1.0) return 1.0;
    // Bias grows with the distortion (bigger texels) and with grazing light.
    float texel = 1.0 / float(shadowMapResolution);
    float bias = texel * f * f * (1.5 + 2.0 * (1.0 - clamp(NdotL, 0.0, 1.0)));
    float z = p.z - bias;
#if SHADOW_FILTER == 0
    return step(z, texture2D(map, p.xy).r);
#elif SHADOW_FILTER == 1
    float s = 0.0;
    s += step(z, texture2D(map, p.xy + vec2(-0.5, -0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(0.5, -0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(-0.5, 0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(0.5, 0.5) * texel).r);
    return s * 0.25;
#else
    float s = 0.0;
    s += step(z, texture2D(map, p.xy + vec2(-1.5, -0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(-1.5, 0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(-0.5, -1.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(-0.5, -0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(-0.5, 0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(-0.5, 1.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(0.5, -1.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(0.5, -0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(0.5, 0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(0.5, 1.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(1.5, -0.5) * texel).r);
    s += step(z, texture2D(map, p.xy + vec2(1.5, 0.5) * texel).r);
    return s / 12.0;
#endif
}
