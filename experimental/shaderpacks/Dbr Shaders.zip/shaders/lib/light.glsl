// Dbr Shaders: forward lighting shared by the lit gbuffers. Vanilla light map, darkened where the sun does not reach.

uniform sampler2D lightmap;
uniform sampler2D shadowtex1;
uniform vec3 shadowLightPosition;
uniform vec3 upPosition;
uniform float rainStrength;

// Sun (or moon) height: 1 overhead, 0 at the horizon. Shadows fade out near the horizon and in rain.
float sunStrength() {
    float h = dot(normalize(shadowLightPosition), normalize(upPosition));
    return clamp(h * 5.0, 0.0, 1.0) * (1.0 - rainStrength * 0.85);
}

// lm: light map coordinates; shadowPos: shadow clip position from the vertex shader; NdotL: light facing.
vec3 lit(vec2 lm, vec3 shadowPos, float NdotL) {
    vec3 light = texture2D(lightmap, lm).rgb;
#ifdef SHADOWS
    float sky = smoothstep(0.25, 0.85, lm.y);
    if (sky > 0.0) {
        float s = NdotL > 0.0 ? shadowAt(shadowtex1, shadowPos, NdotL) : 0.0;
        s = min(s, smoothstep(0.0, 0.25, NdotL));
        float shade = (1.0 - s) * sky * sunStrength();
        // Block light (torches) keeps what it lights.
        float block = smoothstep(0.3, 0.9, lm.x);
        light *= 1.0 - SHADOW_DARKNESS * shade * (1.0 - block * 0.7);
    }
#endif
    return light;
}
