// Dbr Shaders: forward lighting shared by the lit gbuffers.
// Look: warm directional sun (golden when low), warm-brown fill in the shade, short orange torch light, cold dark nights.
// The vanilla light map still decides how much sky and block light reaches a point; this splits the sky part into
// direct sun and fill.

uniform sampler2D lightmap;
uniform sampler2D shadowtex1;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float rainStrength;

// Height of the sun over the horizon: 1 overhead, 0 at the horizon, negative at night.
float sunHeight() {
    return dot(normalize(sunPosition), normalize(upPosition));
}

// How much the shadow light (sun by day, moon by night) is above the horizon, faded by rain.
float sunStrength() {
    float h = dot(normalize(shadowLightPosition), normalize(upPosition));
    return clamp(h * 5.0, 0.0, 1.0) * (1.0 - rainStrength * 0.85);
}

// 1 by day, 0 by night, smooth across sunrise and sunset.
float dayFactor() {
    return smoothstep(-0.08, 0.06, sunHeight());
}

// Colour of the direct light: deep gold at the horizon, warm white high up, cold blue moon at night.
vec3 sunColor() {
    float h = max(sunHeight(), 0.0);
    vec3 day = mix(vec3(1.1, 1.0, 0.72), vec3(1.05, 0.95, 0.82), smoothstep(0.02, 0.55, h));
    vec3 night = vec3(0.50, 0.60, 0.85) * 0.35;
    return mix(night, day, dayFactor());
}

// Fill light where the sun does not reach: warm brown by day (the shadows of the look are amber, not blue).
vec3 fillColor() {
    vec3 day = vec3(0.62, 0.54, 0.46);
    vec3 night = vec3(0.42, 0.45, 0.58);
    return mix(night, day, dayFactor()) * mix(1.0, 1.15, rainStrength);
}

// Face orientation from screen derivatives, toward the camera (terrain has no reliable normal attribute).
vec3 faceNormal(vec3 viewPos) {
    vec3 n = normalize(cross(dFdx(viewPos), dFdy(viewPos)));
    return dot(n, viewPos) > 0.0 ? -n : n;
}

// lm: light map coordinates; shadowPos: shadow clip position from the vertex shader; NdotL: light facing.
vec3 lit(vec2 lm, vec3 shadowPos, float NdotL) {
    vec3 base = texture2D(lightmap, lm).rgb;
    float sky = smoothstep(0.25, 0.85, lm.y) * sunStrength();
    float s = 1.0;
#ifdef SHADOWS
    if (sky > 0.0) {
        s = NdotL > 0.0 ? shadowAt(shadowtex1, shadowPos, NdotL) : 0.0;
    }
#endif
    float direct = s * smoothstep(0.0, 0.35, NdotL) * clamp(NdotL, 0.0, 1.0);
    // Sky part: fill everywhere, sun on what faces it. 1.0 on a face lit head-on; SHADOW_DARKNESS sets the fill.
    vec3 skyLight = fillColor() * (1.0 - SHADOW_DARKNESS) + sunColor() * SUN_STRENGTH * direct;
    vec3 light = base * mix(vec3(1.0), skyLight, sky);
    // Block light (torches): orange, and it keeps what it lights in the shade.
    float block = smoothstep(0.35, 0.95, lm.x);
    light = max(light, base * vec3(1.15, 0.78, 0.48) * block * TORCH_STRENGTH);
    return light;
}
