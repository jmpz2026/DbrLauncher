// Dbr Shaders: options. Each one shows in Video > Shaderpack; the profiles in shaders.properties set them together.

#define SHADOWS // Sun and moon shadows.
const int shadowMapResolution = 2048; // Shadow map size per side. [512 1024 2048 3072 4096]
const float shadowDistance = 80.0; // Blocks covered by the shadow map. [48.0 64.0 80.0 96.0 128.0 160.0]
const float sunPathRotation = -25.0; // Tilt of the sun path, in degrees. [-40.0 -30.0 -25.0 -15.0 0.0 15.0 25.0]
#define SHADOW_FILTER 2 // 0 hard edges, 1 soft (4 samples), 2 softer (12 samples), 3 smooth (bilinear, 16 taps; for recording). [0 1 2 3]
#define SHADOW_DARKNESS 0.25 // How much light a shadow takes away. [0.25 0.35 0.45 0.55 0.65 0.75]
#define SUN_STRENGTH 1.15 // Direct sunlight. [0.6 0.7 0.85 1.0 1.15]
#define TORCH_STRENGTH 1.0 // Torch and lamp light. [0.7 0.85 1.0 1.2]
#define SSAO // Soft shade in corners and under ledges.
#define SSAO_STRENGTH 0.85 // [0.4 0.55 0.7 0.85 1.0]

#define BLOOM // Glow around bright things: ki, lava, glowstone, the sun.
#define BLOOM_STRENGTH 0.65 // [0.25 0.35 0.5 0.65 0.8 1.0]
#define GODRAYS // Sun rays when the sun is low.
#define GODRAYS_STRENGTH 0.35 // [0.15 0.25 0.35 0.5 0.7]
#define KI_GLOW // Ki attacks from Dragon Block C shine and bloom.

#define WAVING_PLANTS // Grass, flowers, crops and leaves move with the wind.
#define WATER_REFLECTION 1 // 0 off, 1 sky reflection on water. [0 1]
#define HEIGHT_FOG // Low thin fog in valleys and far away, thicker in rain.
#define FOG_DENSITY 1.0 // [0.5 0.75 1.0 1.5 2.0]


#define EXPOSURE 0.9 // [0.85 0.9 0.95 1.0 1.05 1.1 1.2]
#define SATURATION 1.3 // [1.0 1.2 1.3 1.45 1.6 1.8]
#define VIBRANCE 0.2 // Extra colour for dull tones. [0.0 0.2 0.4 0.6 0.8]
#define WARMTH 0.3 // Warm white balance. [0.0 0.3 0.5 1.0 1.5]
#define CONTRAST 1.16 // [1.0 1.04 1.08 1.12 1.16 1.2]
#define VIGNETTE // Slightly darker corners.

// IDs from block.properties and entity.properties.
#define ID_PLANT 10001.0
#define ID_DOUBLE_PLANT 10002.0
#define ID_LEAVES 10003.0
#define ID_WATER 10010.0
#define ID_EMISSIVE 10020.0
#define ID_KI 10000
