#version 120
// Dbr Shaders: entities. Vanilla face shading on the vertex; the fragment side makes ki attacks glow.
#include "/lib/settings.glsl"
#include "/lib/vertex.glsl"

uniform int entityId;

void main() {
    vec4 player = gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex);
    vec3 normal = normalize(gl_NormalMatrix * gl_Normal);
    setupVertex(player, normal, -1.0);
    // Ki stays full bright; everything else gets half the vanilla face shading back (the sun adds the rest).
    if (entityId != ID_KI) col.rgb *= mix(1.0, vanillaShade(normal), 0.5);
}
