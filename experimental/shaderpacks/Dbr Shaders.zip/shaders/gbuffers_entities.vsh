#version 120
// Dbr Shaders: entities. Same as textured_lit; the fragment side makes ki attacks glow.
#include "/lib/settings.glsl"
#include "/lib/vertex.glsl"

void main() {
    vec4 player = gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex);
    setupVertex(player, normalize(gl_NormalMatrix * gl_Normal), -1.0);
}
