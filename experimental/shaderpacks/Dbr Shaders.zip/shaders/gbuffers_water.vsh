#version 120
// Dbr Shaders: translucent terrain (water, stained glass, ice).
#include "/lib/settings.glsl"
#include "/lib/vertex.glsl"

attribute vec4 mc_Entity;
varying float material;

void main() {
    vec4 player = gbufferModelViewInverse * (gl_ModelViewMatrix * gl_Vertex);
    material = mc_Entity.x;
    setupVertex(player, normalize(gl_NormalMatrix * gl_Normal), -1.0);
}
