#version 120
// Dbr Shaders: bloom added, then the colour grade of the look: exposure, filmic curve (dense blacks, soft whites),
// warm white balance, saturation with vibrance, olive greens, contrast and a light vignette.
#include "/lib/settings.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex4;

varying vec2 uv;

// Filmic curve: toe for dense blacks, shoulder that rolls highlights off instead of clipping.
vec3 filmic(vec3 x) {
    x = max(x, 0.0);
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

void main() {
    vec3 c = texture2D(colortex0, uv).rgb;
#ifdef BLOOM
    c += texture2D(colortex4, uv).rgb * BLOOM_STRENGTH * vec3(1.05, 0.95, 0.82);
#endif
    c *= EXPOSURE;
    c = filmic(c);
    // Black point: the look has dense, slightly crushed blacks.
    c = max(c - 0.03, 0.0) / 0.97;
    // Warm white balance.
    c *= mix(vec3(1.0), vec3(1.07, 1.0, 0.86), WARMTH);
    // Greens toward olive: where green leads, lift red a little and take some blue.
    float g = max(c.g - max(c.r, c.b), 0.0);
    c.r += g * 0.35;
    c.b -= g * 0.15;
    // Saturation, then vibrance (pushes the dull colours more than the vivid ones).
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, SATURATION);
    float mx = max(c.r, max(c.g, c.b)), mn = min(c.r, min(c.g, c.b));
    float sat = mx > 0.0 ? (mx - mn) / mx : 0.0;
    l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, 1.0 + VIBRANCE * (1.0 - sat));
    // Foliage: green-led pixels get 20 % more saturation so the greens read olive, not moss.
    float leaf = smoothstep(0.0, 0.08, c.g - c.b) * step(c.r, c.g * 1.1);
    l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, 1.0 + 0.2 * leaf);
    c = (c - 0.5) * CONTRAST + 0.5;
#ifdef VIGNETTE
    vec2 v = uv - 0.5;
    c *= 1.0 - dot(v, v) * 0.15;
#endif
    gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
