#version 120
// Dbr Shaders: bloom added, exposure, saturation, contrast and vignette.
#include "/lib/settings.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex4;

varying vec2 uv;

void main() {
    vec3 c = texture2D(colortex0, uv).rgb;
#ifdef BLOOM
    c += texture2D(colortex4, uv).rgb * BLOOM_STRENGTH;
#endif
    c *= EXPOSURE;
    // Soft shoulder: values past 0.8 roll off instead of clipping (bloom can push above 1).
    c = mix(c, 0.8 + 0.2 * (1.0 - exp(-(c - 0.8) * 5.0)), step(0.8, c));
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, SATURATION);
    c = (c - 0.5) * CONTRAST + 0.5;
#ifdef VIGNETTE
    vec2 v = uv - 0.5;
    c *= 1.0 - dot(v, v) * 0.35;
#endif
    gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
