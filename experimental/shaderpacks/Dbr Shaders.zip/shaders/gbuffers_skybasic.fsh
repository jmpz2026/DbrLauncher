#version 120
// Dbr Shaders: sky. Pale clear blue overhead, lighter toward the horizon, peach near the sun at sunrise and sunset.
#include "/lib/settings.glsl"

uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float rainStrength;

varying vec4 col;
varying vec3 viewPos;

void main() {
    vec3 c = col.rgb;
    vec3 dir = normalize(viewPos);
    vec3 up = normalize(upPosition);
    float h = dot(normalize(sunPosition), up);
    float day = smoothstep(-0.08, 0.06, h);
    float above = dot(dir, up);
    // Pale clear blue overhead by day, whatever the vanilla colour at this hour (the references keep a celeste sky
    // even at golden hour), lighter toward the horizon.
    float horizon = 1.0 - smoothstep(0.0, 0.45, above);
    vec3 celeste = mix(vec3(0.62, 0.77, 0.93), vec3(0.80, 0.86, 0.92), horizon);
    c = mix(c, celeste * max(dot(c, vec3(0.333)) * 1.25, 0.75), day * (1.0 - rainStrength) * 0.7);
    c = mix(c, c * 0.75 + vec3(0.25), horizon * 0.5 * day);
    // Golden hour: peach band low in the sky, strongest toward the sun.
    float golden = day * (1.0 - smoothstep(0.08, 0.45, h)) * (1.0 - rainStrength);
    float towardSun = pow(max(dot(dir, normalize(sunPosition)), 0.0), 2.0);
    vec3 peach = vec3(1.0, 0.68, 0.50);
    c = mix(c, peach * (0.75 + 0.25 * towardSun), golden * horizon * (0.45 + 0.4 * towardSun));
    // Away from the sun the low sky turns lavender-pink, as in the reference sunsets.
    float awaySun = pow(max(-dot(dir, normalize(sunPosition)), 0.0), 1.5);
    c = mix(c, vec3(0.80, 0.72, 0.88), golden * horizon * awaySun * 0.45);
    c = mix(c, gl_Fog.color.rgb, clamp((gl_FogFragCoord - gl_Fog.start) * gl_Fog.scale, 0.0, 1.0) * 0.2);
/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(c, col.a);
}
