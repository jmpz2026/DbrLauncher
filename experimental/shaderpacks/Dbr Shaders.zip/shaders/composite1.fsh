#version 120
// Dbr Shaders: bloom, part 1. Bright parts (and anything marked emissive) blurred sideways into colortex3.
#include "/lib/settings.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform float viewWidth;

varying vec2 uv;

vec3 bright(vec2 p) {
    vec3 c = texture2D(colortex0, p).rgb;
    float e = texture2D(colortex1, p).r;
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    return c * max(smoothstep(0.72, 1.0, l), e);
}

void main() {
    float px = 2.0 / viewWidth;
    vec3 s = bright(uv) * 0.2270;
    s += (bright(uv + vec2(px, 0.0)) + bright(uv - vec2(px, 0.0))) * 0.1945;
    s += (bright(uv + vec2(2.0 * px, 0.0)) + bright(uv - vec2(2.0 * px, 0.0))) * 0.1216;
    s += (bright(uv + vec2(3.0 * px, 0.0)) + bright(uv - vec2(3.0 * px, 0.0))) * 0.0540;
    s += (bright(uv + vec2(4.0 * px, 0.0)) + bright(uv - vec2(4.0 * px, 0.0))) * 0.0162;
/* DRAWBUFFERS:3 */
    gl_FragData[0] = vec4(s, 1.0);
}
