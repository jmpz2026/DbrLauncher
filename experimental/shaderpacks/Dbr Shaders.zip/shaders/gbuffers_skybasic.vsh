#version 120
// Dbr Shaders: sky dome, void plane, sunrise fan and stars. View position for the gradient in the fragment side.
varying vec4 col;
varying vec3 viewPos;

void main() {
    gl_Position = ftransform();
    col = gl_Color;
    viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
    gl_FogFragCoord = length(viewPos);
}
